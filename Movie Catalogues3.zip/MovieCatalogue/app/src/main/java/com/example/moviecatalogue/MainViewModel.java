package com.example.moviecatalogue;

import android.util.Log;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;

import cz.msebera.android.httpclient.Header;

public class MainViewModel extends ViewModel {
    public static final String API_KEY = "2c81ff6176898dc8d141c5e26256691c";
    private MutableLiveData<ArrayList<Item>> listItem = new MutableLiveData<>();

    void setMovie(){
        AsyncHttpClient client = new AsyncHttpClient();
        final ArrayList<Item> listMovie = new ArrayList<>();
        String url = "https://api.themoviedb.org/3/movie/popular?api_key=" + API_KEY;

        client.get(url, new AsyncHttpResponseHandler() {
            @Override
            public void onSuccess(int statusCode, Header[] headers, byte[] responseBody) {
                try {
                    String result = new String(responseBody);
                    JSONObject responseObject = new JSONObject(result);
                    JSONArray list = responseObject.getJSONArray("results");

                    for (int i = 0; i < list.length(); i++) {
                        JSONObject movie = list.getJSONObject(i);
                        Item item = new Item();

                        item.setPhoto("http://image.tmdb.org/t/p/w185" + movie.getString("poster_path"));
                        item.setTitle(movie.getString("title"));
                        item.setSysnopsis(movie.getString("overview"));

                        listMovie.add(item);
                    }
                    listItem.postValue(listMovie);
                } catch (Exception e){
                    Log.d("Exception", "ERROR: " + e.getMessage());
                }
            }

            @Override
            public void onFailure(int statusCode, Header[] headers, byte[] responseBody, Throwable error) {
                Log.d("onFailure", "ERROR: " + error.getMessage());
            }
        });
    }

    void setTvShow(){
        AsyncHttpClient client = new AsyncHttpClient();
        final ArrayList<Item> listTvShow = new ArrayList<>();
        String url = "https://api.themoviedb.org/3/tv/popular?api_key=" + API_KEY;

        client.get(url, new AsyncHttpResponseHandler() {
            @Override
            public void onSuccess(int statusCode, Header[] headers, byte[] responseBody) {
                try {
                    String result = new String(responseBody);
                    JSONObject responseObject = new JSONObject(result);
                    JSONArray list = responseObject.getJSONArray("results");

                    for (int i = 0; i < list.length(); i++) {
                        JSONObject movie = list.getJSONObject(i);
                        Item item = new Item();

                        item.setPhoto("http://image.tmdb.org/t/p/w185" + movie.getString("poster_path"));
                        item.setTitle(movie.getString("name"));
                        item.setSysnopsis(movie.getString("overview"));

                        listTvShow.add(item);
                    }
                    listItem.postValue(listTvShow);
                } catch (Exception e){
                    Log.d("Exception", "ERROR: " + e.getMessage());
                }
            }

            @Override
            public void onFailure(int statusCode, Header[] headers, byte[] responseBody, Throwable error) {
                Log.d("onFailure", "ERROR: " + error.getMessage());
            }
        });
    }

    LiveData<ArrayList<Item>> getItem(){
        return listItem;
    }
}
